#testcommandwindow.py

import IPython
import matplotlib
import numpy as np
import pandas as pd
import sklearn
import wordcloud

print("IPython version: {}".format(IPython.__version__))
print("matplotlib version: {}".format(matplotlib.__version__))
print("numpy version: {}".format(np.__version__))
print("pandas version: {}".format(pd.__version__))
print("sklearn version: {}".format(sklearn.__version__))
print("wordcloud version: {}".format(wordcloud.__version__))